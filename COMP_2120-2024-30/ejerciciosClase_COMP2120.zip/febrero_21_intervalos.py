# Si x pertenece a un intervalo de (1, 3) entonces imprima el numero que
# esta en el conjunto.

# 1 < x and x < 3

# if (1 < x and x < 3) then
# 	display "el numero esta en el conjunto"
# endif

# Union de intervalos
# () or () or ()
