# escriba un programa que numeros consecutivos comenzando en 1 hasta 10

# [1,2,3,4,5,6,7,8,8,9,10]

# for
# for contador = 1 to 10, step = 1
# 	print contador
# endfor

# while
# contador = 1
# while contador <= 10
# 	print contador
# 	contador += 1
# endwhile

# do
# contador = 1
# do
# 	print contador
# 	contador += 1
# while contador <= 10

# inicio
# suma = 0
# for contador = 1 to 10, step = 1
# 	suma = suma + contador
# endfor
# print "la suma es", suma
# fin
