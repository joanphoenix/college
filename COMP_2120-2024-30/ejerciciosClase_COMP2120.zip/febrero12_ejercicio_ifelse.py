print("Ingrese el numero:")
x = float(input())

if x < 0:
    print("Numero Negativo")
    print("Fin del programa")

else:
    print("Numero Positivo")
