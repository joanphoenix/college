from marzo20_funciones import sumamultiplos

print(sumamultiplos(40, 80, 7))
