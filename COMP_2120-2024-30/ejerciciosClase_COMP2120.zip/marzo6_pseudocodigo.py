# hacer un programa que calcule las potencias de 2:
# 1, 2, 4, 8, 16, 32, 64, 128

# inicio
# potencia = 1
# for contador = 1 to 7, step = 1
# 	potencia = potencia * 2
# endfor
# print potencia
# end

# while
# incio
#  potencia = 1
#  contador = 1
#  while (contador <= 7)
#   potencia = potencia * 2
# 	print potencia
#   contador = contador + 1
#  endwhile
# end

# do
# incio
# potencia = 1
# contador = 1
# do
# 	potencia = potencia * 2
# 	print potencia
# 	contador = contador + 1
# 	while (contador <= 7)
# endwhile
# end


# inicio
# potencia = 1
# while (potencia <= 1024)
# 	potencia = potencia * 2
# print potencia
# endwhile
# end

# do-while
# inicio
# potencia = 1
# do
# 	potencia = potencia * 2
# 	print potencia
# while (potencia <= 1024)
# endwhile
# end
