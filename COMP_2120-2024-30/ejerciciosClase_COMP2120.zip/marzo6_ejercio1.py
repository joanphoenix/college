for num in range(1, 60, 2):
    print(num)
