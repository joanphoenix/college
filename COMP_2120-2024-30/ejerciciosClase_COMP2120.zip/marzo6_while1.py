# while
# Programa que imprime los numeros del 1 al 10
contador = 1
while contador <= 10:
    print(contador)
    contador += 1
