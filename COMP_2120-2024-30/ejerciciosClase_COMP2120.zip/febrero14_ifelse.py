# inicio

# declarar variables:x, y son reales

#entrada 

#print("ingrese el valor")
#x=float(input())

#proceso

#  if then else order

#if x<-5:
#	y=x+1
#else:
#	if -5<=x AND x<10:
#		y=x*x
#	else:
#		if x>=10:
#			y=-3
#		endif
#	endif	
#end if

#salida
#print  el valor de y

#fin


#Resumen:
#Entrada:
#Salida:
#Proceso:
